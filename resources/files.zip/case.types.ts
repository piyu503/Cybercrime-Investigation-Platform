export type CaseStatus = "open" | "in_progress" | "closed" | "pending";

export interface FileMetadata {
  file_id: string;
  filename: string;
  content_type: string;
  size_bytes: number;
  uploaded_at: string;
  url?: string;
}

export interface Case {
  case_id: string;
  title: string;
  description?: string;
  status: CaseStatus;
  created_at: string;
  updated_at: string;
  files: FileMetadata[];
  metadata?: Record<string, unknown>;
}

export interface CreateCasePayload {
  title: string;
  description?: string;
  status?: CaseStatus;
  metadata?: Record<string, unknown>;
}

export interface CaseResponse {
  data: Case;
  message?: string;
}

export interface UploadResponse {
  case_id: string;
  files: FileMetadata[];
  uploaded_count: number;
  message?: string;
}
