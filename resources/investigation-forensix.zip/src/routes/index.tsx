import { createBrowserRouter } from "react-router-dom";
import { AppLayout } from "@/layouts/AppLayout";
import Dashboard from "@/pages/Dashboard";
import Cases from "@/pages/Cases";
import Evidence from "@/pages/Evidence";
import Timeline from "@/pages/Timeline";
import Reports from "@/pages/Reports";
import Settings from "@/pages/Settings";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <AppLayout />,
    children: [
      { index: true, element: <Dashboard /> },
      { path: "cases", element: <Cases /> },
      { path: "evidence", element: <Evidence /> },
      { path: "timeline", element: <Timeline /> },
      { path: "reports", element: <Reports /> },
      { path: "settings", element: <Settings /> },
    ],
  },
]);
