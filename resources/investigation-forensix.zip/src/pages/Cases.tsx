import { Briefcase } from "lucide-react";
import { PageHeader } from "@/components/layout/PageHeader";
import { PlaceholderPanel } from "@/components/layout/PlaceholderPanel";

export default function Cases() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        eyebrow="Module 02"
        title="Cases"
        description="Open, archived, and assigned case files across all units."
      />
      <PlaceholderPanel icon={Briefcase} module="Cases" />
    </div>
  );
}
