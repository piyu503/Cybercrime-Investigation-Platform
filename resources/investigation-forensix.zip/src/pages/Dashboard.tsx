import { LayoutDashboard } from "lucide-react";
import { PageHeader } from "@/components/layout/PageHeader";
import { PlaceholderPanel } from "@/components/layout/PlaceholderPanel";

export default function Dashboard() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        eyebrow="Module 01"
        title="Dashboard"
        description="Operational overview across active cases, evidence intake, and assigned tasks."
      />
      <PlaceholderPanel icon={LayoutDashboard} module="Dashboard" />
    </div>
  );
}
